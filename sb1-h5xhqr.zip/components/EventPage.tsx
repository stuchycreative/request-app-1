"use client"

import { useState, useCallback, useEffect } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, ThumbsUp, ThumbsDown, Music2, Calendar, Menu, Search } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const LASTFM_API_BASE_URL = 'https://ws.audioscrobbler.com/2.0/';
const LASTFM_API_KEY = 'c39447d197e82a0e43214756989f6d60';

interface Song {
  id: number;
  title: string;
  artist: string;
  album: string;
  image: string;
  votes: number;
  userVote: 'up' | 'down' | null;
}

export default function EventPage() {
  const [isSearchVisible, setIsSearchVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Song[]>([]);
  const [requestedSongs, setRequestedSongs] = useState<Song[]>([]);
  const [otherRequests, setOtherRequests] = useState<Song[]>([]);
  const { toast } = useToast();

  const handleSearch = useCallback(async (query: string) => {
    if (query.length < 3) {
      setSearchResults([]);
      return;
    }

    try {
      const response = await fetch(`${LASTFM_API_BASE_URL}?method=track.search&track=${query}&api_key=${LASTFM_API_KEY}&format=json`);
      const data = await response.json();
      const tracks = data.results.trackmatches.track;

      const formattedResults: Song[] = tracks.map((track: any, index: number) => ({
        id: index,
        title: track.name,
        artist: track.artist,
        album: '',
        image: track.image[2]['#text'] || '',
        votes: 0,
        userVote: null,
      }));

      setSearchResults(formattedResults);
    } catch (error) {
      console.error('Error searching for songs:', error);
      toast({
        title: "Error",
        description: "Failed to search for songs. Please try again.",
        variant: "destructive",
      });
    }
  }, [toast]);

  const handleAddSong = useCallback((song: Song) => {
    setRequestedSongs(prev => [...prev, song]);
    setSearchResults([]);
    setSearchQuery('');
    setIsSearchVisible(false);
    toast({
      title: "Song Added",
      description: `${song.title} by ${song.artist} has been added to your requests.`,
    });
  }, [toast]);

  const handleVote = useCallback((songId: number, voteType: 'up' | 'down') => {
    setOtherRequests(prev => 
      prev.map(song => 
        song.id === songId
          ? { ...song, votes: voteType === 'up' ? song.votes + 1 : song.votes - 1, userVote: voteType }
          : song
      ).sort((a, b) => b.votes - a.votes)
    );
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <header className="relative">
        <Image
          src="https://als.band/wp-content/uploads/2024/10/ALS-Band_home-video.jpg"
          alt="Zolene & The ALS Band"
          width={1200}
          height={675}
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
        <div className="absolute bottom-0 left-0 p-4 text-white">
          <h1 className="text-2xl font-bold">Zolene & The ALS Band</h1>
          <p className="text-sm">Londonderry Arms | October 15, 2024</p>
        </div>
      </header>

      <main className="flex-grow p-4 max-w-md mx-auto w-full">
        <Button
          onClick={() => setIsSearchVisible(!isSearchVisible)}
          className="w-full mb-4 bg-[#c8a66c] hover:bg-[#b18e4f] text-white py-3 rounded-full"
        >
          REQUEST A SONG
        </Button>

        {isSearchVisible && (
          <div className="mb-4">
            <div className="flex items-center bg-white rounded-full overflow-hidden shadow">
              <Search className="h-5 w-5 ml-3 text-gray-400" />
              <Input
                type="text"
                placeholder="Type here..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  handleSearch(e.target.value);
                }}
                className="flex-grow border-none focus:ring-0"
              />
            </div>
            {searchResults.length > 0 && (
              <ul className="mt-2 bg-white rounded-lg shadow">
                {searchResults.map((song) => (
                  <li key={song.id} className="flex items-center p-2 border-b last:border-b-0">
                    <Image
                      src={song.image || '/placeholder-album.jpg'}
                      alt={`${song.album} cover`}
                      width={40}
                      height={40}
                      className="mr-2 rounded"
                    />
                    <div className="flex-grow">
                      <p className="font-semibold">{song.title}</p>
                      <p className="text-sm text-gray-600">{song.artist}</p>
                    </div>
                    <Button
                      onClick={() => handleAddSong(song)}
                      className="ml-2 p-1"
                      variant="ghost"
                    >
                      <Plus className="h-5 w-5" />
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <Tabs defaultValue="your-requests" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="your-requests">Your Requests</TabsTrigger>
            <TabsTrigger value="requested-by-others">Requested by Others</TabsTrigger>
          </TabsList>
          <TabsContent value="your-requests">
            <ul className="space-y-2">
              {requestedSongs.map((song) => (
                <li key={song.id} className="bg-white p-2 rounded-lg shadow flex items-center">
                  <Image
                    src={song.image || '/placeholder-album.jpg'}
                    alt={`${song.album} cover`}
                    width={40}
                    height={40}
                    className="mr-2 rounded"
                  />
                  <div>
                    <p className="font-semibold">{song.title}</p>
                    <p className="text-sm text-gray-600">{song.artist}</p>
                  </div>
                </li>
              ))}
            </ul>
          </TabsContent>
          <TabsContent value="requested-by-others">
            <ul className="space-y-2">
              {otherRequests.map((song) => (
                <li key={song.id} className="bg-white p-2 rounded-lg shadow flex items-center">
                  <Image
                    src={song.image || '/placeholder-album.jpg'}
                    alt={`${song.album} cover`}
                    width={40}
                    height={40}
                    className="mr-2 rounded"
                  />
                  <div className="flex-grow">
                    <p className="font-semibold">{song.title}</p>
                    <p className="text-sm text-gray-600">{song.artist}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      onClick={() => handleVote(song.id, 'down')}
                      variant="ghost"
                      size="sm"
                      className={song.userVote === 'down' ? 'text-red-500' : ''}
                    >
                      <ThumbsDown className="h-4 w-4" />
                    </Button>
                    <span>{song.votes}</span>
                    <Button
                      onClick={() => handleVote(song.id, 'up')}
                      variant="ghost"
                      size="sm"
                      className={song.userVote === 'up' ? 'text-green-500' : ''}
                    >
                      <ThumbsUp className="h-4 w-4" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-white border-t">
        <nav className="flex justify-around p-2">
          <Button variant="ghost" className="flex flex-col items-center">
            <Menu className="h-6 w-6" />
            <span className="text-xs">Menu</span>
          </Button>
          <Button variant="ghost" className="flex flex-col items-center">
            <Calendar className="h-6 w-6" />
            <span className="text-xs">Events</span>
          </Button>
          <Button variant="ghost" className="flex flex-col items-center">
            <Music2 className="h-6 w-6" />
            <span className="text-xs">Songs</span>
          </Button>
        </nav>
      </footer>
    </div>
  );
}