"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

export interface BorderBeamProps extends React.HTMLAttributes<HTMLDivElement> {
  duration?: number
}

export const BorderBeam = React.forwardRef<HTMLDivElement, BorderBeamProps>(
  ({ className, duration = 2000, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "relative flex h-full w-full items-center justify-center overflow-hidden rounded-lg border border-slate-800 px-4 py-8 shadow-2xl",
          className
        )}
        {...props}
      >
        <div
          className="pointer-events-none absolute -inset-px opacity-[0.015]"
          style={{
            maskImage: `
              radial-gradient(
                100% 50% at 50% 0%,
                black 0%,
                transparent 100%
              )
            `,
            WebkitMaskImage: `
              radial-gradient(
                100% 50% at 50% 0%,
                black 0%,
                transparent 100%
              )
            `,
          }}
        >
          <div className="animate-border-beam absolute inset-px" />
        </div>
        {props.children}
      </div>
    )
  }
)
BorderBeam.displayName = "BorderBeam"