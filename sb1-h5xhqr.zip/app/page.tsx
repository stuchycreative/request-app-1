import EventPage from '@/components/EventPage';

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <EventPage />
    </main>
  );
}